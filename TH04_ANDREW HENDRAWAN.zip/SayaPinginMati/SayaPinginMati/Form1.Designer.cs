﻿namespace SayaPinginMati
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.negara = new System.Windows.Forms.ComboBox();
            this.namatimnegara = new System.Windows.Forms.ComboBox();
            this.posisikitadimana = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.listboxbesaryangkitabisalihatorang = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.bebasajanamanya = new System.Windows.Forms.TextBox();
            this.negaranegarayangberada = new System.Windows.Forms.TextBox();
            this.kotayangtercintah = new System.Windows.Forms.TextBox();
            this.namaorangyajelaspastiadamosoknamanyakosonggakkanyaapuun = new System.Windows.Forms.TextBox();
            this.nomerdibelakangbaju = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Soccer Team List";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(32, 134);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Choose Team";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(32, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Choose Nation";
            // 
            // negara
            // 
            this.negara.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.negara.FormattingEnabled = true;
            this.negara.Location = new System.Drawing.Point(71, 89);
            this.negara.Name = "negara";
            this.negara.Size = new System.Drawing.Size(172, 33);
            this.negara.TabIndex = 3;
            this.negara.SelectionChangeCommitted += new System.EventHandler(this.comboBox1_SelectionChangeCommitted);
            // 
            // namatimnegara
            // 
            this.namatimnegara.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.namatimnegara.FormattingEnabled = true;
            this.namatimnegara.Location = new System.Drawing.Point(71, 158);
            this.namatimnegara.Name = "namatimnegara";
            this.namatimnegara.Size = new System.Drawing.Size(172, 33);
            this.namatimnegara.TabIndex = 4;
            this.namatimnegara.SelectedIndexChanged += new System.EventHandler(this.ampundah_SelectedIndexChanged);
            // 
            // posisikitadimana
            // 
            this.posisikitadimana.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posisikitadimana.FormattingEnabled = true;
            this.posisikitadimana.Items.AddRange(new object[] {
            "GK",
            "DF",
            "MF",
            "FW"});
            this.posisikitadimana.Location = new System.Drawing.Point(485, 434);
            this.posisikitadimana.Name = "posisikitadimana";
            this.posisikitadimana.Size = new System.Drawing.Size(45, 33);
            this.posisikitadimana.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(363, 79);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 25);
            this.label4.TabIndex = 6;
            this.label4.Text = "Team Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(363, 125);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(117, 25);
            this.label5.TabIndex = 7;
            this.label5.Text = "Team Country";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(363, 170);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 25);
            this.label6.TabIndex = 8;
            this.label6.Text = "Team City";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(368, 343);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 25);
            this.label7.TabIndex = 9;
            this.label7.Text = "Player Name";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(368, 389);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(113, 25);
            this.label8.TabIndex = 10;
            this.label8.Text = "Player Number";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(368, 434);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(114, 25);
            this.label9.TabIndex = 11;
            this.label9.Text = "Player Position";
            // 
            // listboxbesaryangkitabisalihatorang
            // 
            this.listboxbesaryangkitabisalihatorang.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listboxbesaryangkitabisalihatorang.FormattingEnabled = true;
            this.listboxbesaryangkitabisalihatorang.ItemHeight = 25;
            this.listboxbesaryangkitabisalihatorang.Location = new System.Drawing.Point(27, 215);
            this.listboxbesaryangkitabisalihatorang.Name = "listboxbesaryangkitabisalihatorang";
            this.listboxbesaryangkitabisalihatorang.Size = new System.Drawing.Size(230, 279);
            this.listboxbesaryangkitabisalihatorang.TabIndex = 12;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(27, 506);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(89, 34);
            this.button1.TabIndex = 13;
            this.button1.Text = "Remove";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(367, 215);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(91, 32);
            this.button2.TabIndex = 14;
            this.button2.Text = "Add";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(372, 479);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(84, 32);
            this.button3.TabIndex = 15;
            this.button3.Text = "Add";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // bebasajanamanya
            // 
            this.bebasajanamanya.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bebasajanamanya.Location = new System.Drawing.Point(492, 82);
            this.bebasajanamanya.Name = "bebasajanamanya";
            this.bebasajanamanya.Size = new System.Drawing.Size(173, 33);
            this.bebasajanamanya.TabIndex = 16;
            // 
            // negaranegarayangberada
            // 
            this.negaranegarayangberada.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.negaranegarayangberada.Location = new System.Drawing.Point(492, 126);
            this.negaranegarayangberada.Name = "negaranegarayangberada";
            this.negaranegarayangberada.Size = new System.Drawing.Size(173, 33);
            this.negaranegarayangberada.TabIndex = 17;
            // 
            // kotayangtercintah
            // 
            this.kotayangtercintah.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kotayangtercintah.Location = new System.Drawing.Point(492, 173);
            this.kotayangtercintah.Name = "kotayangtercintah";
            this.kotayangtercintah.Size = new System.Drawing.Size(173, 33);
            this.kotayangtercintah.TabIndex = 18;
            // 
            // namaorangyajelaspastiadamosoknamanyakosonggakkanyaapuun
            // 
            this.namaorangyajelaspastiadamosoknamanyakosonggakkanyaapuun.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.namaorangyajelaspastiadamosoknamanyakosonggakkanyaapuun.Location = new System.Drawing.Point(485, 346);
            this.namaorangyajelaspastiadamosoknamanyakosonggakkanyaapuun.Name = "namaorangyajelaspastiadamosoknamanyakosonggakkanyaapuun";
            this.namaorangyajelaspastiadamosoknamanyakosonggakkanyaapuun.Size = new System.Drawing.Size(181, 33);
            this.namaorangyajelaspastiadamosoknamanyakosonggakkanyaapuun.TabIndex = 19;
            // 
            // nomerdibelakangbaju
            // 
            this.nomerdibelakangbaju.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nomerdibelakangbaju.Location = new System.Drawing.Point(485, 390);
            this.nomerdibelakangbaju.Name = "nomerdibelakangbaju";
            this.nomerdibelakangbaju.Size = new System.Drawing.Size(181, 33);
            this.nomerdibelakangbaju.TabIndex = 20;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(341, 29);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(110, 25);
            this.label10.TabIndex = 21;
            this.label10.Text = "Adding Team";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(341, 302);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(111, 25);
            this.label11.TabIndex = 22;
            this.label11.Text = "Adding Player";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(694, 556);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.nomerdibelakangbaju);
            this.Controls.Add(this.namaorangyajelaspastiadamosoknamanyakosonggakkanyaapuun);
            this.Controls.Add(this.kotayangtercintah);
            this.Controls.Add(this.negaranegarayangberada);
            this.Controls.Add(this.bebasajanamanya);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.listboxbesaryangkitabisalihatorang);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.posisikitadimana);
            this.Controls.Add(this.namatimnegara);
            this.Controls.Add(this.negara);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox negara;
        private System.Windows.Forms.ComboBox namatimnegara;
        private System.Windows.Forms.ComboBox posisikitadimana;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ListBox listboxbesaryangkitabisalihatorang;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox bebasajanamanya;
        private System.Windows.Forms.TextBox negaranegarayangberada;
        private System.Windows.Forms.TextBox kotayangtercintah;
        private System.Windows.Forms.TextBox namaorangyajelaspastiadamosoknamanyakosonggakkanyaapuun;
        private System.Windows.Forms.TextBox nomerdibelakangbaju;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
    }
}

